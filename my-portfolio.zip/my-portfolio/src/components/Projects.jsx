import React from "react";
import Button from "./Button";

const Projects = () => {
  const projects = [
    {
      name: "Portfolio Website",
      description: "A React-based personal portfolio",
    },
    {
      name: "Sneakerhead Website",
      description: "A Sneakers store website to buy branded sneakers online",
    },
  ];

  const handleClick = () => {
    alert("Project coming soon!");
  };

  return (
    <section id="projects" className="my-4 text-center">
      <h2>Projects</h2>
      {projects.map((proj, idx) => (
        <div key={idx} className="border rounded p-3 my-2 bg-secondary">
          <h4>{proj.name}</h4>
          <p>{proj.description}</p>
          <Button onClick={handleClick} label="View Project" />
        </div>
      ))}
    </section>
  );
};

export default Projects;
