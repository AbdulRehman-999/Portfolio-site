import React from "react";

const AboutMe = ({ name, picture }) => {
  return (
    <section id="about" className="text-center my-4">
      <img
        src="./my-img.png"
        alt="Profile"
        className="rounded-circle"
        width="150"
      />
      <h2 className="mt-3">{name}</h2>
      <p>
        I'm a 5th semester BS Computer Science student at the University of
        Central Punjab. I'm a passionate designer and developer learning Web
        Development. I enjoy building dynamic web apps and improving my coding
        skills every day. I also do crypto trading as a side hustle. I also have
        about 8 months hands-on experience of Blender software and had made a
        different 3D model projects.
      </p>
    </section>
  );
};

export default AboutMe;
