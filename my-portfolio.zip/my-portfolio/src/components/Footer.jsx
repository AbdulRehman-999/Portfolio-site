import React from "react";

const Footer = () => {
  const year = new Date().getFullYear();
  return (
    <footer className="bg-dark text-light text-center py-3 mt-5">
      <p>Made by Abdul Rehman – {year}</p>
    </footer>
  );
};

export default Footer;
