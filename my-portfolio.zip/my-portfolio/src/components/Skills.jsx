import React from "react";

const Skills = () => {
  const skillList = [
    "HTML",
    "CSS",
    "JavaScript",
    "React",
    "BLENDER",
    "Trading",
  ];
  return (
    <section id="skills" className="my-4 text-center">
      <h2>Skills</h2>
      <ul className="list-inline">
        {skillList.map((skill, index) => (
          <li key={index} className="list-inline-item badge bg-warning m-2 p-2">
            {skill}
          </li>
        ))}
      </ul>
    </section>
  );
};

export default Skills;
