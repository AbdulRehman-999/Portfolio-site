import React from "react";

const Button = ({ onClick, label }) => {
  return (
    <button className="btn btn-success mt-2 bg-warning" onClick={onClick}>
      {label}
    </button>
  );
};

export default Button;
